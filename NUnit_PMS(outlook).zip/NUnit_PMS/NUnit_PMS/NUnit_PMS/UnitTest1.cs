using ClassLibrary_PMS.Models;
using ClassLibrary_PMS;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace NUnit_PMS
{
    [TestFixture]
    public class UnitTest1    
       {
             Assembly assembly = null;
             Type classAdminName = null;
             Employee oE = null;
             Attendance oA = null;
             Bank oB = null;
             Salary_Splitup oS = null;
             Payroll oP = null;
             AdminManager oAM = null;

        [SetUp]
        public void Setup()
        {
             assembly = Assembly.Load("ClassLibrary_PMS");
             classAdminName = assembly.GetType("ClassLibrary_PMS.Models.AdminManager");
             oE = new Employee();
             oA = new Attendance();
             oB = new Bank();
             oP = new Payroll();
             oS = new Salary_Splitup();
             oAM = new AdminManager();
        }

        
         [Test]
        public void TestClassAdmin()
        {
            if (classAdminName == null)
                Assert.Fail("No class with the name 'AdminManager' is implemented as required OR Did you change the class name");
        }


      //-----------------------------Employee  ModelClass Test ---------------------------------------//
        [Test]
        public void TestGetEmployeeList()
        {
            using (var context = new DBContext_PMS())
            {
                var mock = new Mock<IEnumerable<Employee>>();
                 mock.Setup(x => x.GetEnumerator()).Returns(oAM.GetEmployeesList().GetEnumerator());
                int expected = 0;
                expected = mock.Object.Count<Employee>();
                if (expected == 0)
                {
                    Assert.Fail("No Employee available.");
                }
            }
        }
       

        [Test]
        public void TestPostEmployee()
        {
            using (var context = new DBContext_PMS())
            {
               oE.EmployeeID = "6";
                oE.FirstName = "Rahul";
                oE.LastName = "Shaikh";
                oE.Designation = "pa";
                oE.Gender = "M";
                oE.DOJ = "2009-07-04";
                oE.MailID = "sohel@gmail.com";
                oE.PhoneNumber = 1234567890;
                oE.PAN = "la167gh";
                oAM.PostEmployee(oE);
            }
            using (var context = new DBContext_PMS())
            {
                var mock = new Mock<IEnumerable<Employee>>();
                mock.Setup(x => x.GetEnumerator()).Returns(oAM.GetEmployeesList().GetEnumerator());
                int expected = 1;
                bool isExists = false;
                string insertid = "0";
                if (expected > 0)
                {
                    foreach (var i in mock.Object)
                    {
                        if (i.FirstName.Equals("Rahul"))
                        {
                            isExists = true;
                            insertid = i.EmployeeID;
                            break;
                        }
                        else
                        {
                            isExists = false;
                            continue;
                        }
                    }
                }
                if (!isExists)
                    Assert.Fail("No Employee added.");
                else
                {
                    oAM.DeleteEmployee(insertid);
                }
            }
        }

        //-------------------------Attendance ModelClass Test ----------------------------------//
        [Test]
        public void TestGetAttendanceList()
        { 

            using (var context = new DBContext_PMS())
            {
                var mock = new Mock<IEnumerable<Attendance>>();
                mock.Setup(x => x.GetEnumerator()).Returns(oAM.GetAttendancesList().GetEnumerator());
                int expected = mock.Object.Count<Attendance>();
                if (expected == 0)
                {
                    Assert.Fail("No Attendance Availbale");
                }
            }
        }

        [Test]
        public void TestPostAttendance()
        {
            using (var context = new DBContext_PMS())
            {
               // oA.AttendanceID = 10;
                oA.Year = "2022";
                oA.Month = "2";
                oA.Total_Days = 30;
                oA.Working_Days = 28;
                oA.EmployeeID = "2";
                oAM.PostAttendance(oA);

            }
            using (var context = new DBContext_PMS())
            {
                var mock = new Mock<IEnumerable<Attendance>>();
                mock.Setup(x => x.GetEnumerator()).Returns(oAM.GetAttendancesList().GetEnumerator());
                int expected = 1;
                bool isExists = false;
                int insertid = 0;
                if (expected > 0)
                {
                    foreach (var i in mock.Object)
                    {
                        if (i.EmployeeID.Equals("2") && i.Month == "2")
                        {
                            isExists = true;
                            insertid = i.AttendanceID;
                            break;
                        }
                        else
                        {
                            isExists = false;
                            continue;
                        }
                    }
                }
                if (!isExists)
                    Assert.Fail("No Employee added.");
                else
                {
                    oAM.DeleteAttendance(insertid);
                }
            }
          
        }

        //----------------------------------Bank ModelClass Test ----------------------------------//
        [Test]
        public void TestGetBankList()
        
        {
            using (var context = new DBContext_PMS())
            {
                var mock = new Mock<IEnumerable<Bank>>();
                mock.Setup(x => x.GetEnumerator()).Returns(oAM.GetBanksList().GetEnumerator());
                int expected = 0;
                expected = mock.Object.Count<Bank>();
                if (expected == 0)
                {
                   Assert.Fail(" No Bank Details Available");
                }
            } 
        }


        [Test]
        public void TestPostBank()
        {
            using (var context = new DBContext_PMS())
            {
               //oB.Serial_No = 2;
                oB.Account_Number = 675756566;
                oB.IFSC = "SBI9090324";
                oB.Bank_Name = "Test";
                oB.EmployeeID = "1";
                oAM.PostBank(oB);
            }
            using (var context = new DBContext_PMS())
            {
                var mock = new Mock<IEnumerable<Bank>>();
                mock.Setup(x => x.GetEnumerator()).Returns(oAM.GetBanksList().GetEnumerator());

                int expected = 1;
                bool isExists = false;
                long insertid = 0;
                if (expected > 0)
                {
                    foreach (var i in mock.Object)
                    {
                        if (i.Account_Number.Equals(675756566))
                        {
                            isExists = true;
                            insertid = i.Account_Number;
                            break;
                        }
                        else
                        {
                            isExists = false;
                            continue;
                        }
                    }
                }
                if (!isExists)
                    Assert.Fail("No Employee added.");
                else
                {
                 //   oAM.DeleteBank(insertid);
                }
            }
        }
     
    }
}



