﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using ClassLibrary_PMS.Models;

namespace EmployeeController.Controllers
{
    public class Salary_SplitupController : ApiController
    {
        private DBContext_PMS db = new DBContext_PMS();

        // GET: api/Salary_Splitup
        public IQueryable<Salary_Splitup> GetSalary_Splitups()
        {
            return db.Salary_Splitups;
        }

        // GET: api/Salary_Splitup/5
        [ResponseType(typeof(Salary_Splitup))]
        public IHttpActionResult GetSalary_Splitup(string id)
        {
            Salary_Splitup salary_Splitup = db.Salary_Splitups.Find(id);
            if (salary_Splitup == null)
            {
                return NotFound();
            }

            return Ok(salary_Splitup);
        }

        // PUT: api/Salary_Splitup/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutSalary_Splitup(string id, Salary_Splitup salary_Splitup)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != salary_Splitup.Designation)
            {
                return BadRequest();
            }

            db.Entry(salary_Splitup).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Salary_SplitupExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Salary_Splitup
        [ResponseType(typeof(Salary_Splitup))]
        public IHttpActionResult PostSalary_Splitup(Salary_Splitup salary_Splitup)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Salary_Splitups.Add(salary_Splitup);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (Salary_SplitupExists(salary_Splitup.Designation))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = salary_Splitup.Designation }, salary_Splitup);
        }

        // DELETE: api/Salary_Splitup/5
        [ResponseType(typeof(Salary_Splitup))]
        public IHttpActionResult DeleteSalary_Splitup(string id)
        {
            Salary_Splitup salary_Splitup = db.Salary_Splitups.Find(id);
            if (salary_Splitup == null)
            {
                return NotFound();
            }

            db.Salary_Splitups.Remove(salary_Splitup);
            db.SaveChanges();

            return Ok(salary_Splitup);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool Salary_SplitupExists(string id)
        {
            return db.Salary_Splitups.Count(e => e.Designation == id) > 0;
        }
    }
}