import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SignInComponent } from './Login/sign-in/sign-in.component';
import { HomePageComponent } from './Admin/home-page/home-page.component';
import {HttpClientModule} from '@angular/common/http';
import { SignUpComponent } from './Login/sign-up/sign-up.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginService } from './shared/login.service';
import { EmployeeService } from './shared/employee.service';
import { ToastrModule } from 'ngx-toastr';
import { EmployeeDetailsComponent } from './Admin/home-page/employee-details/employee-details.component';
import { AddEmployeeComponent } from './Admin/home-page/employee-details/add-employee/add-employee.component';
import {MatDialogModule} from '@angular/material/dialog';

import { LoginDetailsComponent } from './Admin/home-page/login-details/login-details.component';
import { DesignationSalaryComponent } from './Admin/home-page/designation-salary/designation-salary.component';
import { AddDesignationComponent } from './Admin/home-page/designation-salary/add-designation/add-designation.component';

import {MatInputModule} from '@angular/material/input';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { BankDetailsComponent } from './Admin/home-page/bank-details/bank-details.component';
import { AddBankComponent } from './Admin/home-page/bank-details/add-bank/add-bank.component';
import { AttendanceComponent } from './Admin/home-page/attendance/attendance.component';
import { HomeComponent } from './Employee/home/home.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ProfileComponent } from './Employee/home/profile/profile.component';

import { BankComponent } from './Employee/home/bank/bank.component';

import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import {MatCardModule} from '@angular/material/card';
import { EmpAttendanceComponent } from './Employee/home/emp-attendance/emp-attendance.component';
import {MatTableModule} from '@angular/material/table';
import { SalarySlipComponent } from './Employee/home/salary-slip/salary-slip.component';



@NgModule({
  declarations: [
    AppComponent,
    SignInComponent,
    HomePageComponent,
    SignUpComponent,
    EmployeeDetailsComponent,
    AddEmployeeComponent,
    LoginDetailsComponent,
    DesignationSalaryComponent,
    AddDesignationComponent,
    BankDetailsComponent,
    AddBankComponent,
    HomeComponent,
    AttendanceComponent,
    ProfileComponent,
    BankComponent,
    EmpAttendanceComponent,
    SalarySlipComponent
    
   
  ],
  imports: [
    
    FormsModule,
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    MatDialogModule,
    Ng2SearchPipeModule,

    MatInputModule,
    MatIconModule,
    MatButtonModule,
    NgbModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatCardModule,
    MatTableModule
   
  ],
  entryComponents:[AddEmployeeComponent],
  providers: [LoginService,EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { 
}
