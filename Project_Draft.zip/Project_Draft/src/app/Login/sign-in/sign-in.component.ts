
import { Component, OnInit ,ElementRef,ViewChild} from '@angular/core';
import {NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { LoginService } from 'src/app/shared/login.service';


@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {
  isValid: boolean = true;
flag:boolean=false;   

  constructor(public service:LoginService,private router:Router,private toastr:ToastrService) { 
      
    }

  ngOnInit(): void {
    this.resetForm();
    this.service.getPassword().subscribe(x=>{this.service.LoginList=x});
   
  }
 onSubmit()
{  
  if(this.validateForm())
  {
   for(var item of this.service.AdminLogin)
   {
     if(item.EmployeeID==this.service.formData.EmployeeID && item.Password==this.service.formData.Password)
     {
      this.flag=true;
      this.router.navigate(['/HomePage']);
      
     }
   }
  for(var item of this.service.LoginList)
    {
      if(this.service.formData.EmployeeID==item.EmployeeID && this.service.formData.Password==item.Password)
      {
        this.flag=true;
        this.router.navigate(['/Employee-home']);
       
      }
    }
    if(this.flag==false)
    {
      this.toastr.info("Entered credentials is invalid!!","Error");
      this.resetForm();
    }
  
  }
}

  resetForm(form?: NgForm){
    if(form!=null)
    form.resetForm();
    this.service.formData={
      EmployeeName:"",
      EmployeeID: "",
      Password:"",
      Serial_No:0
    }
  }

  validateForm(){
    this.isValid = true;
    if(this.service.formData.EmployeeID=='')
    this.isValid=false;
    else if(this.service.formData.Password=='')
    this.isValid=false;
    return this.isValid;
  }
  
  focus(event:any){
     this.service.valueID=event.target.value;
  }
}








