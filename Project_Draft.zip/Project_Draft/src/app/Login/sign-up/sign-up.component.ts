import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

import { Login } from 'src/app/shared/login.model';
import { LoginService } from 'src/app/shared/login.service';
import { ToastrService } from 'ngx-toastr';
import { EmployeeService } from 'src/app/shared/employee.service';


@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  isValid: boolean = true;
  flag: boolean = true;


  constructor(public service: LoginService, private router: Router, private toastr: ToastrService,
    private empService: EmployeeService) { }


  ngOnInit(): void {
    this.resetForm();
    this.service.getPassword().subscribe(x => { this.service.LoginList = x });

  }

  Submit() {
    if (this.validateForm()) {
      for (var item of this.service.LoginList) {
        if (this.service.formData.EmployeeID == item.EmployeeID) {
          this.toastr.info('Employee ID already exist!!');
          this.flag = false;
          break;
        }
      }
      if (this.flag == true) {
        this.service.SavePassword().subscribe(res => {
          this.resetForm();
          this.toastr.success('Registered Succussfully!!', 'Confirmation');
          this.router.navigate(['/sign-in']);
        });

      }
    }
  }

  resetForm(form?: NgForm) {
    if (form != null)
      form.resetForm();
    this.service.formData= {
      EmployeeName: '',
      EmployeeID: "",
      Password: "",
      Serial_No: 0,
    }
  }

  validateForm() {
    this.isValid = true;
    if (this.service.formData.EmployeeName == '')
      this.isValid = false;
    if (this.service.formData.EmployeeID == '')
      this.isValid = false;
    else if (this.service.formData.Password == '')
      this.isValid = false;
    return this.isValid;
  }


}
