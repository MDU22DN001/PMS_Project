import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AttendanceComponent } from './Admin/home-page/attendance/attendance.component';
import { BankDetailsComponent } from './Admin/home-page/bank-details/bank-details.component';
import { DesignationSalaryComponent } from './Admin/home-page/designation-salary/designation-salary.component';
import { EmployeeDetailsComponent } from './Admin/home-page/employee-details/employee-details.component';
import { HomePageComponent } from './Admin/home-page/home-page.component';
import { LoginDetailsComponent } from './Admin/home-page/login-details/login-details.component';
import { BankComponent } from './Employee/home/bank/bank.component';
import { EmpAttendanceComponent } from './Employee/home/emp-attendance/emp-attendance.component';

import { HomeComponent } from './Employee/home/home.component';
import { ProfileComponent } from './Employee/home/profile/profile.component';
import { SalarySlipComponent } from './Employee/home/salary-slip/salary-slip.component';
import { SignInComponent } from './Login/sign-in/sign-in.component';
import { SignUpComponent } from './Login/sign-up/sign-up.component';

const routes: Routes = [
  {path:'',redirectTo:'sign-in',pathMatch:'full'},
  {path:'sign-in',component:SignInComponent},
 
  {path:'HomePage',component:HomePageComponent},
  {path:'Sign-up',component:SignUpComponent},
  {path:"Employee-details",component:EmployeeDetailsComponent},
  {path:"Login-details",component:LoginDetailsComponent},
  {path:"designation-salary",component:DesignationSalaryComponent},
  {path:"Bank-details",component:BankDetailsComponent},
  {path:"Attendance",component:AttendanceComponent},
 {path:"Employee-home",component:HomeComponent},
 {path:"profile",component:ProfileComponent},
 {path:"bank",component:BankComponent},
 {path:"EmpAttendance",component:EmpAttendanceComponent},
 {path:"Salary-Slip",component:SalarySlipComponent}
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
