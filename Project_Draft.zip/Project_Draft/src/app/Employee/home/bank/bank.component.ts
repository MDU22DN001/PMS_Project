import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { Bank } from 'src/app/shared/bank.model';
import { BankService } from 'src/app/shared/bank.service';
import { LoginService } from 'src/app/shared/login.service';
import { environment } from 'src/environments/environment';
declare let $:any;

@Component({
  selector: 'app-bank',
  templateUrl: './bank.component.html',
  styleUrls: ['./bank.component.css']
})
export class BankComponent implements OnInit {
  Empbank:Bank[];
  
  constructor(public bankService:BankService,public service:LoginService,public http:HttpClient,
    private toastr:ToastrService) { }

  ngOnInit(): void {
  
    
      $(document).ready(function () {
        $('#sidebarCollapse').on('click', function () {
            $('#sidebar').toggleClass('active');
            $('#content').toggleClass('active');
        });
  
        $('.more-button,.body-overlay').on('click', function () {
            $('#sidebar,.body-overlay').toggleClass('show-nav');
        });
  
    });
  
      this.bankService.getBank().subscribe((z:Bank[])=>{
        for(var item of z)
        {
          if(this.service.formData.EmployeeID==item.EmployeeID)
          {
            this.bankService.bankNo=item.Serial_No;
          }
        }
            this.GetEmployeebank(this.bankService.bankNo).subscribe((z:any)=>{
              this.Empbank=z; 
            });
          
         });
             
    }
     GetEmployeebank(id:number){
      return this.http.get<any>(environment.Url+'/Banks/'+id);
    }

    update(){
      this.http.put<any>(environment.Url+'/Banks/'+this.Empbank[0].Serial_No, this.Empbank)
    .subscribe(x=>{ 
  });
  this.toastr.success("Successfully Submitted","Bank Details");
    }
 
}
