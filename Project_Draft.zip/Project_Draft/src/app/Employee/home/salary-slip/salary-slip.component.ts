import { Component, OnInit } from '@angular/core';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { SplitupService } from 'src/app/shared/splitup.service';
import { LoginService } from 'src/app/shared/login.service';
import { EmployeeService } from 'src/app/shared/employee.service';
import { Payroll } from 'src/app/shared/payroll.model';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { AttendanceService } from 'src/app/shared/attendance.service';
import { Attendance } from 'src/app/shared/attendance.model';
declare let $:any;

@Component({
  selector: 'app-salary-slip',
  templateUrl: './salary-slip.component.html',
  styleUrls: ['./salary-slip.component.css']
})
export class SalarySlipComponent implements OnInit {
designation:string;
Salary:Payroll[]=[];
Id:number;
displayArr:Attendance[];

  public convertToPDF()

  {

  html2canvas(document.getElementById("content")!).then( canvas=> {

  const contentDataURL = canvas.toDataURL('image/png')

  let pdf = new jsPDF('p', 'mm', 'a4');
  var width = pdf.internal.pageSize.getWidth()-30;
  var height = (canvas.height * width / canvas.width)+12;
  pdf.addImage(contentDataURL, 'PNG', 15, 7, width, height)
  pdf.save('Payroll_Management_System_Payslip.pdf');
  });

  }

  constructor(public SplitupService:SplitupService,public service:LoginService,
    public empService:EmployeeService,public http:HttpClient,public attendanceService:AttendanceService) { }

  ngOnInit(): void {
   
    
      $(document).ready(function () {
        $('#sidebarCollapse').on('click', function () {
            $('#sidebar').toggleClass('active');
            $('#content').toggleClass('active');
        });
  
        $('.more-button,.body-overlay').on('click', function () {
            $('#sidebar,.body-overlay').toggleClass('show-nav');
        });
  
    });
  
    this.empService.getEmployee().subscribe((z:any)=>{
      for(var item of z)
      {
        if(this.service.formData.EmployeeID==item.EmployeeID)
        {
          this.designation=item.Designation;
        }
      }
          this.GetDesignation(this.designation).subscribe((y:any)=>{
            this.Salary=y;
            console.log(this.Salary); 
          });
         });
         this.attendanceService.getAttendance().subscribe((x:Attendance[])=>{
          for(var item of x)
          {
            if(this.service.formData.EmployeeID==item.EmployeeID)
            {
              this.Id=item.AttendanceID;
            }
          }
              this.GetEmployeeAttendance(this.Id).subscribe((y:any)=>{
                this.displayArr=y; 
                console.log(this.displayArr);
              });
            
           });
  }
  GetDesignation(id:string){
    return this.http.get<any>(environment.Url+'/Salary_Splitup/'+id);
  }
  GetEmployeeAttendance(id:number){
    return this.http.get<any>(environment.Url+'/Attendances/'+id);
  }

  

}


