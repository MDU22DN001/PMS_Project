import { HttpClient } from '@angular/common/http';
import { ANALYZE_FOR_ENTRY_COMPONENTS, Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs';
import { BankService } from 'src/app/shared/bank.service';
import { Employee } from 'src/app/shared/employee.model';
import { EmployeeService } from 'src/app/shared/employee.service';
import { LoginService } from 'src/app/shared/login.service';
import { environment } from 'src/environments/environment';
declare let $:any;


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

List:Employee[];


  constructor(public empService:EmployeeService,public service:LoginService,private http:HttpClient,
    public bankService:BankService,private toastr:ToastrService) { }
  
  
  ngOnInit(): void {
    $(document).ready(function () {
      $('#sidebarCollapse').on('click', function () {
          $('#sidebar').toggleClass('active');
          $('#content').toggleClass('active');
      });

      $('.more-button,.body-overlay').on('click', function () {
          $('#sidebar,.body-overlay').toggleClass('show-nav');
      });

  });

      this.GetEmployeeVal(this.service.formData.EmployeeID).subscribe((z:any)=>{
        this.List=z; 
      }
      );  
  }
   GetEmployeeVal(id:any){
    return this.http.get<any>(environment.Url+'/Employees/'+id);
  }

  update(){
    this.http.put<any>(environment.Url+'/Employees/'+this.List[0].EmployeeID, this.List)
  .subscribe(x=>{ });
  this.toastr.success("Successfully Submitted","Personal Details");
  }
}
