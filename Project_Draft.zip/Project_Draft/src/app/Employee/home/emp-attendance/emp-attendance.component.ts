import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDatepicker } from '@angular/material/datepicker';
import { NgbCalendar, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { Attendance } from 'src/app/shared/attendance.model';
import { AttendanceService } from 'src/app/shared/attendance.service';
import { LoginService } from 'src/app/shared/login.service';
import { environment } from 'src/environments/environment';
declare let $:any;

@Component({
  selector: 'app-emp-attendance',
  templateUrl: './emp-attendance.component.html',
  styleUrls: ['./emp-attendance.component.css']
})
export class EmpAttendanceComponent implements OnInit {
  displayArr:Attendance[];
  model: NgbDateStruct;
  date: {year: number, month: number};
  Id:number;

  constructor(public attendanceService:AttendanceService,private calendar: NgbCalendar,
    public service:LoginService,private http:HttpClient,private toastr:ToastrService) { }
 
 
num:number;
  dob:string;
  ngOnInit(): void {
    
      $(document).ready(function () {
        $('#sidebarCollapse').on('click', function () {
            $('#sidebar').toggleClass('active');
            $('#content').toggleClass('active');
        });
  
        $('.more-button,.body-overlay').on('click', function () {
            $('#sidebar,.body-overlay').toggleClass('show-nav');
        });
  
    });
  
    this.attendanceService.getAttendance().subscribe((z:Attendance[])=>{
      for(var item of z)
      {
        if(this.service.formData.EmployeeID==item.EmployeeID)
        {
          this.Id=item.AttendanceID;
        }
      }
          this.GetEmployeeAttendance(this.Id).subscribe((y:any)=>{
            this.displayArr=y; 
            console.log(this.displayArr);
            
          });
        
       });
           
  }
   GetEmployeeAttendance(id:number){
    return this.http.get<any>(environment.Url+'/Attendances/'+id);
  }
    
  
  submit()
  {
    this.attendanceService.attendanceClass={
      AttendanceID:0,
    EmployeeID:'',
    Date:this.model.day,
    Year:this.model.year,
    Month:this.model.month,
    Total_Days:this.func(this.model.month),
    Working_Days:this.displayArr[0].Working_Days
    };
    this.attendanceService.Empattendance.push(this.attendanceService.attendanceClass);
   
  
  }
  func(month: number) {
   if(month==1 || month==3 || month==5 || month==7 || month==8 || month==10 || month==12)
   {
      return 31;
   }
   else if(month==2)
   {
     return 28;
   }
   else{return 30;}
   
  }
 
  selectToday() {
    this.model = this.calendar.getToday();
  }
 
 onDelete(index:number){
   this.attendanceService.Empattendance.splice(index,1);
 }

 onSubmit(){
   this.num = this.displayArr.length+1;
   this.displayArr[0].Working_Days += this.num;
   this.http.put<any>(environment.Url+'/Attendances/'+this.displayArr[0].AttendanceID, this.displayArr[0])
   .subscribe(x=>{ });
   this.toastr.success("Successfully Submitted","Attendance");
   this.attendanceService.Empattendance.splice(0,this.num);
 }

}
