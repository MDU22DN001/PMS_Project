export class Employee {
    EmployeeID:string;
    FirstName:string;
    LastName:string;
    Designation:string;
    Gender:string;
    DOJ:string;
    PhoneNumber:number;
    EmailID:string;
    PAN:string;
}
