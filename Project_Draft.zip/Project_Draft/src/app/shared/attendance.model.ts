export class Attendance {
    AttendanceID:number;
    EmployeeID:string;
    Date:number;
    Year:number;
    Month:number
    Total_Days:number;
    Working_Days:number;
}
