export class Splitup {
    Designation:string;
    Basic_Pay:number;
    HRA:number;
    PF : number;
    Medical_Allowance :number;
    Special_Allowance :number;
    Tax_Deduction :number;
    Gross_Pay :number;
    Net_Pay :number;

}
