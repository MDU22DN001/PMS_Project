export class Login {
    Serial_No:number;
    EmployeeID:string;
    Password:string;
    EmployeeName:string;
}
