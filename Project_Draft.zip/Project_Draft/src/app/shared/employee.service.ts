import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Employee } from './employee.model';


@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  EmployeeList:Employee[];

  constructor(private http:HttpClient) { }
  
  getEmployee():Observable<Employee[]>{
    return this.http.get<Employee[]>(environment.Url+'/Employees');
  }

}
