import { Payroll } from './payroll.model';

describe('Payroll', () => {
  it('should create an instance', () => {
    expect(new Payroll()).toBeTruthy();
  });
});
