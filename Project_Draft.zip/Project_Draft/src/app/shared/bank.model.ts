export class Bank {
    Serial_No:number;
    EmployeeName:string;
    EmployeeID:string;
    Account_Number:number;
    IFSC:string;
    Bank_Name:string;
    PAN:string;
}
