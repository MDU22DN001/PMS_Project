import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Bank } from './bank.model';

@Injectable({
  providedIn: 'root'
})
export class BankService {
  BankList:Bank[];
  bankNo:number;

  constructor(private http:HttpClient) { }
  
  getBank():Observable<Bank[]>{
    return this.http.get<Bank[]>(environment.Url+'/Banks');
  }

}
