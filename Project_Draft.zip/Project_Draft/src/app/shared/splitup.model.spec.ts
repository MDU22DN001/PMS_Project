import { Splitup } from './splitup.model';

describe('Splitup', () => {
  it('should create an instance', () => {
    expect(new Splitup()).toBeTruthy();
  });
});
