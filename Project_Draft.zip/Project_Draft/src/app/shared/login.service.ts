import { Injectable } from '@angular/core';
import { Login } from './login.model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Employee } from './employee.model';



@Injectable({
  providedIn: 'root'
})
export class LoginService {
  formData:Login;
  LoginList : Login[];
  AdminLogin:Login[]=[{EmployeeID:'Admin',Password:'admin@123',Serial_No:0,EmployeeName:"Admin"}];
 valueID:string;
 
  constructor(private http:HttpClient) { }


  getPassword(): Observable<Login[]> {
    return this.http.get<Login[]>(environment.Url+'/Logins');
  }


  SavePassword(){
      var body={
        ...this.formData,
      }
      return this.http.post(environment.Url+'/Logins',body); 
    }
 
  
}
