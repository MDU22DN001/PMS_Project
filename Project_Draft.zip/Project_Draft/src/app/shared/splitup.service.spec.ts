import { TestBed } from '@angular/core/testing';

import { SplitupService } from './splitup.service';

describe('SplitupService', () => {
  let service: SplitupService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SplitupService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
