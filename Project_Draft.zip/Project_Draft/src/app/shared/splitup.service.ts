import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Splitup } from './splitup.model';

@Injectable({
  providedIn: 'root'
})
export class SplitupService {
  DesignationList:Splitup[];

  constructor(private http:HttpClient) { }
  
  getDesignation(): Observable<Splitup[]> {
    return this.http.get<Splitup[]>(environment.Url+'/Salary_Splitup');
  }
}
