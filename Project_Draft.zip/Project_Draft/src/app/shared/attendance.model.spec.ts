import { Attendance } from './attendance.model';

describe('Attendance', () => {
  it('should create an instance', () => {
    expect(new Attendance()).toBeTruthy();
  });
});
