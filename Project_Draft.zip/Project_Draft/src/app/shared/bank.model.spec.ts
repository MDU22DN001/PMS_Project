import { Bank } from './bank.model';

describe('Bank', () => {
  it('should create an instance', () => {
    expect(new Bank()).toBeTruthy();
  });
});
