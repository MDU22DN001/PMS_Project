import { HttpClient } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Bank } from 'src/app/shared/bank.model';
import { BankService } from 'src/app/shared/bank.service';
import { Employee } from 'src/app/shared/employee.model';
import { EmployeeService } from 'src/app/shared/employee.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-add-bank',
  templateUrl: './add-bank.component.html',
  styleUrls: ['./add-bank.component.css']
})
export class AddBankComponent implements OnInit {
  
  AddBank:Bank;
  isValid: boolean=true;

  constructor(@Inject(MAT_DIALOG_DATA) public data:any,
  public dialogRef:MatDialogRef<AddBankComponent>,public bankService:BankService,
  private http:HttpClient,public empService:EmployeeService) { }

  

  ngOnInit(): void {
    
    if(this.data.Index==null){
      this.AddBank = {
        EmployeeName:'',
        Serial_No:0,
        EmployeeID:"",
        Account_Number:0,
        IFSC:'',
        Bank_Name:'',
        PAN:''
      }}
      else{
      this.AddBank = Object.assign({},this.bankService.BankList[this.data.Index]);
      }

      
  }

  validateForm(AddBank:Bank){
    this.isValid=true;
    if(AddBank.EmployeeID=='')
    this.isValid=false;
    else if(AddBank.Account_Number==0)
    this.isValid=false;
    else if(AddBank.Bank_Name=='')
    this.isValid=false;
    else if(AddBank.IFSC=='')
    this.isValid=false;
    return this.isValid;
  }

  onSubmit(form:NgForm){
  if(this.validateForm(form.value)){
    if(this.data.Index==null)
    {
      this.bankService.BankList.push(this.AddBank);
    this.http.post(environment.Url+'/Banks',this.AddBank).subscribe(res=>{
      this.dialogRef.close();
    });
   
    }
  else
  {
    this.bankService.BankList[this.data.Index]= this.AddBank;
    this.http.put<any>(environment.Url+'/Banks/'+this.AddBank.Serial_No, this.AddBank)
    .subscribe(x=>{ this.dialogRef.close() });
  }
}}

}
