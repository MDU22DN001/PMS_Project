import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { Bank } from 'src/app/shared/bank.model';
import { BankService } from 'src/app/shared/bank.service';
import { LoginService } from 'src/app/shared/login.service';
import { environment } from 'src/environments/environment';
import { AddBankComponent } from './add-bank/add-bank.component';
declare let $:any;

@Component({
  selector: 'app-bank-details',
  templateUrl: './bank-details.component.html',
  styleUrls: ['./bank-details.component.css']
})
export class BankDetailsComponent implements OnInit {

  term!:string;

  constructor(public bankService:BankService,private http:HttpClient,private dialog:MatDialog,
    public toastr:ToastrService,public service:LoginService) { }

  ngOnInit(): void {
    this.bankService.getBank().subscribe((z:Bank[])=>{this.bankService.BankList=z});

    $(document).ready(function () {
      $('#sidebarCollapse').on('click', function () {
          $('#sidebar').toggleClass('active');
          $('#content').toggleClass('active');
      });
  
      $('.more-button,.body-overlay').on('click', function () {
          $('#sidebar,.body-overlay').toggleClass('show-nav');
      });
  
  });
  
  }
  AddBank(Index:any){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = true;
    dialogConfig.disableClose = true;
    dialogConfig.width='50%';
    dialogConfig.data = {Index};
  this.dialog.open(AddBankComponent,dialogConfig);
  }

    DeleteBank(i:any){
        var data=this.bankService.BankList[i];
        this.http.delete(environment.Url+'/Banks/'+data.Serial_No).subscribe(res=>{
          this.toastr.info("Deleted Successfully!!","Bank Details of Employee");
        });
        this.bankService.BankList.splice(i,1);
    }

}
