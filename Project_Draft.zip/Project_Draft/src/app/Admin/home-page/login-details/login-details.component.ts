import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Login } from 'src/app/shared/login.model';
import { LoginService } from 'src/app/shared/login.service';
import { environment } from 'src/environments/environment';
declare let $:any;

@Component({
  selector: 'app-login-details',
  templateUrl: './login-details.component.html',
  styleUrls: ['./login-details.component.css']
})
export class LoginDetailsComponent implements OnInit {
  term!:string;
 

  constructor(public service:LoginService,private http:HttpClient,private  toastr:ToastrService) { }

  ngOnInit(): void {
    this.service.getPassword().subscribe(x=>{this.service.LoginList=x})

    $(document).ready(function () {
      $('#sidebarCollapse').on('click', function () {
          $('#sidebar').toggleClass('active');
          $('#content').toggleClass('active');
      });
  
      $('.more-button,.body-overlay').on('click', function () {
          $('#sidebar,.body-overlay').toggleClass('show-nav');
      });
  
  });
  
  }
  DeletePassword(i:any){
    var data=this.service.LoginList[i];
        this.http.delete(environment.Url+'/Logins/'+data.Serial_No).subscribe(res=>{
        this.toastr.info("Successfully Deleted","Login Details");
        });
        this.service.LoginList.splice(i,1);
  }

}
