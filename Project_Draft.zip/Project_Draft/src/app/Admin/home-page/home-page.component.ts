

import { Component, OnInit, ViewEncapsulation } from '@angular/core';
declare let $:any;

@Component({
  selector: 'app-home-page',
  templateUrl:'./home-page.component.html',
  styleUrls: ['./home-page.component.css'],
 encapsulation: ViewEncapsulation.Emulated
})
export class HomePageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    
    $(document).ready(function () {
      $('#sidebarCollapse').on('click', function () {
          $('#sidebar').toggleClass('active');
          $('#content').toggleClass('active');
      });

      $('.more-button,.body-overlay').on('click', function () {
          $('#sidebar,.body-overlay').toggleClass('show-nav');
      });

  });

  }

}
