import { Component, Inject, OnInit, ViewEncapsulation } from '@angular/core';
import { Employee } from 'src/app/shared/employee.model';
import { MAT_DIALOG_DATA,MatDialogRef} from '@angular/material/dialog';
import { EmployeeService } from 'src/app/shared/employee.service';
import { NgForm } from '@angular/forms';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { SplitupService } from 'src/app/shared/splitup.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css'],
  encapsulation:ViewEncapsulation.Emulated
})
export class AddEmployeeComponent implements OnInit {
  AddEmp:Employee;
  isValid: boolean=true;
  term!:string;

  constructor(@Inject(MAT_DIALOG_DATA) public data:any,
  public dialogRef:MatDialogRef<AddEmployeeComponent>,public empService:EmployeeService,
  private http:HttpClient,public SplitupService:SplitupService) { }

  ngOnInit(): void {

    this.SplitupService.getDesignation().subscribe(x=>{this.SplitupService.DesignationList=x});

    if(this.data.Index==null){
      this.AddEmp = {
        EmployeeID:"",
        FirstName:"",
        LastName:"",
        Designation:"",
        Gender:"",
        DOJ:"",
        PhoneNumber:0,
        EmailID:"",
        PAN:""
      }}
      else{
      this.AddEmp = Object.assign({},this.empService.EmployeeList[this.data.Index]);
      }
  }
  validateForm(AddEmp:Employee){
    this.isValid=true;
    if(AddEmp.EmployeeID=='')
    this.isValid=false;
    else if(AddEmp.FirstName=='')
    this.isValid=false;
    else if(AddEmp.Designation=='')
    this.isValid=false;
    else if(AddEmp.DOJ=='')
    this.isValid=false;
    else if(AddEmp.Gender=='')
    this.isValid=false;
    else if(AddEmp.PhoneNumber==0)
    this.isValid=false;
    else if(AddEmp.EmailID=='')
    this.isValid=false;
    else if(AddEmp.PAN=='')
    this.isValid=false;
    return this.isValid;
  }

  onSubmit(form:NgForm){
  if(this.validateForm(form.value)){
    if(this.data.Index==null)
    {
      if(this.AddEmp.LastName=='')
      this.AddEmp.LastName='-';
      this.empService.EmployeeList.push(this.AddEmp);
    this.http.post(environment.Url+'/Employees',this.AddEmp).subscribe(res=>{
      this.dialogRef.close();
    });
   
    }
  else
  {
    this.empService.EmployeeList[this.data.Index]= this.AddEmp;
    this.http.put<any>(environment.Url+'/Employees/'+this.AddEmp.EmployeeID, this.AddEmp)
    .subscribe(x=>{ this.dialogRef.close() });
  }
}}

}
