import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { MatDialog,MatDialogConfig } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { BankService } from 'src/app/shared/bank.service';
import { Employee } from 'src/app/shared/employee.model';
import { EmployeeService } from 'src/app/shared/employee.service';
import { LoginService } from 'src/app/shared/login.service';
import { environment } from 'src/environments/environment';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
declare let $:any;

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {

  term!:string;
  val: boolean=false;

  constructor(public empService:EmployeeService,private dialog:MatDialog,private http:HttpClient,
    private toastr:ToastrService,public service:LoginService,public bankService:BankService) { }

  ngOnInit(): void {
    this.empService.getEmployee().subscribe((z:Employee[])=>{this.empService.EmployeeList=z});

    $(document).ready(function () {
      $('#sidebarCollapse').on('click', function () {
          $('#sidebar').toggleClass('active');
          $('#content').toggleClass('active');
      });
  
      $('.more-button,.body-overlay').on('click', function () {
          $('#sidebar,.body-overlay').toggleClass('show-nav');
      });
  
  });
  
  }


  AddEmployee(Index:any){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = true;
    dialogConfig.disableClose = true;
    dialogConfig.width='50%';
    dialogConfig.data = {Index};
  this.dialog.open(AddEmployeeComponent,dialogConfig);
  }

    DeleteEmployee(i:any){
        var data=this.empService.EmployeeList[i].EmployeeID;
        this.http.delete(environment.Url+'/Employees/'+data).subscribe(res=>{
         this.toastr.info("Deleted Successfully!!","Employee Details");
        this.empService.EmployeeList.splice(i,1);
    });
}

}

