import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DesignationSalaryComponent } from './designation-salary.component';

describe('DesignationSalaryComponent', () => {
  let component: DesignationSalaryComponent;
  let fixture: ComponentFixture<DesignationSalaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DesignationSalaryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DesignationSalaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
