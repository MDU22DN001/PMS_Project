import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { SplitupService } from 'src/app/shared/splitup.service';
import { environment } from 'src/environments/environment';
import { AddDesignationComponent } from './add-designation/add-designation.component';
declare let $:any;
@Component({
  selector: 'app-designation-salary',
  templateUrl: './designation-salary.component.html',
  styleUrls: ['./designation-salary.component.css']
})
export class DesignationSalaryComponent implements OnInit {
  term!:string;

  constructor(public SplitupService:SplitupService,private dialog:MatDialog,
    private http:HttpClient,public toastr:ToastrService) { }

  ngOnInit(): void {

    $(document).ready(function () {
      $('#sidebarCollapse').on('click', function () {
          $('#sidebar').toggleClass('active');
          $('#content').toggleClass('active');
      });
  
      $('.more-button,.body-overlay').on('click', function () {
          $('#sidebar,.body-overlay').toggleClass('show-nav');
      });
  
  });

  this.SplitupService.getDesignation().subscribe(x=>{this.SplitupService.DesignationList=x});
  }

  AddDesignation(Index:any)
  {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = true;
    dialogConfig.disableClose = true;
    dialogConfig.width='50%';
    dialogConfig.data = {Index};
  this.dialog.open(AddDesignationComponent,dialogConfig);
  }

    DeleteDesignation(i:any){
        var data=this.SplitupService.DesignationList[i];
        this.http.delete(environment.Url+'/Salary_Splitup/'+data.Designation).subscribe(res=>{
          this.toastr.info("Deleted Successfully!!","Designation Salary Details");
        });
        this.SplitupService.DesignationList.splice(i,1);
    }
  

 
}
