import { HttpClient } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Splitup } from 'src/app/shared/splitup.model';
import { SplitupService } from 'src/app/shared/splitup.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-add-designation',
  templateUrl: './add-designation.component.html',
  styleUrls: ['./add-designation.component.css']
})
export class AddDesignationComponent implements OnInit {
  AddSalary:Splitup;
  isValid:boolean=true;

  constructor(@Inject(MAT_DIALOG_DATA) public data:any,
  public dialogRef:MatDialogRef<AddDesignationComponent>,public SplitupService:SplitupService,
  private http:HttpClient) { }

  ngOnInit(): void {
    if(this.data.Index==null){
      this.AddSalary = {
    Designation:'',    
    Basic_Pay:0,
    HRA:0,
    PF :0,
    Medical_Allowance :0,
    Special_Allowance :0,
    Tax_Deduction :0,
    Gross_Pay :0,
    Net_Pay :0
      }}
      else{
      this.AddSalary = Object.assign({},this.SplitupService.DesignationList[this.data.Index]);
      }
  }
  validateForm(AddSalary:Splitup){
    this.isValid=true;
    if(AddSalary.Designation=='')
    this.isValid=false;
    else if(AddSalary.Basic_Pay==0)
    this.isValid=false;
    else if(AddSalary.Gross_Pay==0)
    this.isValid=false;
    else if(AddSalary.HRA==0)
    this.isValid=false;
    else if(AddSalary.Medical_Allowance==0)
    this.isValid=false;
    else if(AddSalary.Net_Pay==0)
    this.isValid=false;
    else if(AddSalary.PF==0)
    this.isValid=false;
    else if(AddSalary.Special_Allowance==0)
    this.isValid=false;
    return this.isValid;
  }

  onSubmit(form:NgForm){
  if(this.validateForm(form.value)){
    if(this.data.Index==null)
    {
      
      this.SplitupService.DesignationList.push(this.AddSalary);
    this.http.post(environment.Url+'/Salary_Splitup',this.AddSalary).subscribe(res=>{
      this.dialogRef.close();
    });
   
    }
  else
  {
    this.SplitupService.DesignationList[this.data.Index]= this.AddSalary;
    this.http.put<any>(environment.Url+'/Salary_Splitup/'+this.AddSalary.Designation, this.AddSalary)
    .subscribe(x=>{ this.dialogRef.close() });
  }
}}
  }

