import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { Attendance } from 'src/app/shared/attendance.model';
import { AttendanceService } from 'src/app/shared/attendance.service';
import { environment } from 'src/environments/environment';
declare let $:any;

@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.css']
})
export class AttendanceComponent implements OnInit {
 
  term!:string;

  constructor(public attendanceService:AttendanceService,private dialog:MatDialog,private http:HttpClient,
    private toastr:ToastrService) { }

  ngOnInit(): void {
    this.attendanceService.getAttendance().subscribe((z:Attendance[])=>{this.attendanceService.AttendanceList=z});

    $(document).ready(function () {
      $('#sidebarCollapse').on('click', function () {
          $('#sidebar').toggleClass('active');
          $('#content').toggleClass('active');
      });
  
      $('.more-button,.body-overlay').on('click', function () {
          $('#sidebar,.body-overlay').toggleClass('show-nav');
      });
  
  });
  
  }

  DeleteAttendance(i:any){
    var data=this.attendanceService.AttendanceList[i];
    this.http.delete(environment.Url+'/Attendances/'+data.AttendanceID).subscribe(res=>{
     this.toastr.info("Deleted Successfully!!","Employee Details");
    });
    this.attendanceService.AttendanceList.splice(i,1);
}
}
