﻿namespace ClassLibrary_PMS.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Create : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Attendances",
                c => new
                    {
                        AttendanceID = c.Int(nullable: false, identity: true),
                        Year = c.Int(nullable: false),
                        Month = c.Int(nullable: false),
                        Total_Days = c.Int(nullable: false),
                        Working_Days = c.Int(nullable: false),
                        EmployeeID = c.String(maxLength: 30),
                    })
                .PrimaryKey(t => t.AttendanceID)
                .ForeignKey("dbo.Employees", t => t.EmployeeID)
                .Index(t => t.EmployeeID);
            
            CreateTable(
                "dbo.Employees",
                c => new
                    {
                        EmployeeID = c.String(nullable: false, maxLength: 30),
                        FirstName = c.String(nullable: false, maxLength: 30),
                        LastName = c.String(maxLength: 30),
                        Designation = c.String(nullable: false, maxLength: 30),
                        Gender = c.String(nullable: false, maxLength: 30),
                        DOJ = c.DateTime(nullable: false),
                        PhoneNumber = c.Long(nullable: false),
                        MailID = c.String(nullable: false, maxLength: 30),
                        PAN = c.String(nullable: false, maxLength: 30),
                    })
                .PrimaryKey(t => t.EmployeeID);
            
            CreateTable(
                "dbo.Banks",
                c => new
                    {
                        Serial_No = c.Int(nullable: false, identity: true),
                        Account_Number = c.Long(nullable: false),
                        IFSC = c.String(nullable: false, maxLength: 25),
                        Bank_Name = c.String(nullable: false, maxLength: 100),
                        EmployeeID = c.String(maxLength: 30),
                    })
                .PrimaryKey(t => t.Serial_No)
                .ForeignKey("dbo.Employees", t => t.EmployeeID)
                .Index(t => t.EmployeeID);
            
            CreateTable(
                "dbo.Logins",
                c => new
                    {
                        Serial_No = c.Int(nullable: false, identity: true),
                        Password = c.String(nullable: false, maxLength: 30),
                        EmployeeID = c.String(maxLength: 30),
                    })
                .PrimaryKey(t => t.Serial_No)
                .ForeignKey("dbo.Employees", t => t.EmployeeID)
                .Index(t => t.EmployeeID);
            
            CreateTable(
                "dbo.Payrolls",
                c => new
                    {
                        Serial_No = c.Int(nullable: false, identity: true),
                        EmployeeID = c.String(maxLength: 30),
                        Designation = c.String(maxLength: 30),
                        AttendanceID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Serial_No)
                .ForeignKey("dbo.Attendances", t => t.AttendanceID, cascadeDelete: true)
                .ForeignKey("dbo.Employees", t => t.EmployeeID)
                .ForeignKey("dbo.Salary_Splitup", t => t.Designation)
                .Index(t => t.EmployeeID)
                .Index(t => t.Designation)
                .Index(t => t.AttendanceID);
            
            CreateTable(
                "dbo.Salary_Splitup",
                c => new
                    {
                        Designation = c.String(nullable: false, maxLength: 30),
                        Basic_Pay = c.Int(nullable: false),
                        HRA = c.Int(nullable: false),
                        PF = c.Int(nullable: false),
                        Medical_Allowance = c.Int(nullable: false),
                        Special_Allowance = c.Int(nullable: false),
                        Tax_Deduction = c.Int(nullable: false),
                        Gross_Pay = c.Int(nullable: false),
                        Net_Pay = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Designation);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Payrolls", "Designation", "dbo.Salary_Splitup");
            DropForeignKey("dbo.Payrolls", "EmployeeID", "dbo.Employees");
            DropForeignKey("dbo.Payrolls", "AttendanceID", "dbo.Attendances");
            DropForeignKey("dbo.Logins", "EmployeeID", "dbo.Employees");
            DropForeignKey("dbo.Banks", "EmployeeID", "dbo.Employees");
            DropForeignKey("dbo.Attendances", "EmployeeID", "dbo.Employees");
            DropIndex("dbo.Payrolls", new[] { "AttendanceID" });
            DropIndex("dbo.Payrolls", new[] { "Designation" });
            DropIndex("dbo.Payrolls", new[] { "EmployeeID" });
            DropIndex("dbo.Logins", new[] { "EmployeeID" });
            DropIndex("dbo.Banks", new[] { "EmployeeID" });
            DropIndex("dbo.Attendances", new[] { "EmployeeID" });
            DropTable("dbo.Salary_Splitup");
            DropTable("dbo.Payrolls");
            DropTable("dbo.Logins");
            DropTable("dbo.Banks");
            DropTable("dbo.Employees");
            DropTable("dbo.Attendances");
        }
    }
}
