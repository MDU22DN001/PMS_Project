﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace ClassLibrary_PMS.Models
{
    public class DBContext_PMS : DbContext
    { 
        public virtual DbSet<Employee> Employees { get; set; }
        public virtual DbSet<Attendance> Attendances { get; set; }
        public virtual DbSet<Bank> Banks { get; set; }
        public virtual DbSet<Payroll> Payrolls { get; set; }
        public virtual DbSet<Login> Logins { get; set; }
        public virtual DbSet<Salary_Splitup> Salary_Splitups { get; set; }

    }
}