﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary_PMS.Models

{
    public class Employee
    {
        [Key]
        [Display(Name = "Enter Employee ID")]
        [Required(ErrorMessage = "Employee ID is Required")]
        [StringLength(30, MinimumLength = 1, ErrorMessage = "Employee Id must be within 0-30 characters")]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string EmployeeID { get; set; }

        [Display(Name = "Enter First Name")]
        [Required(ErrorMessage = "First Name is Required")]
        [StringLength(30, MinimumLength = 1, ErrorMessage = "First Name must be within 0-30 characters")]
        public string FirstName { get; set; }

        [Display(Name = "Enter Last Name")]
        [StringLength(30, MinimumLength = 1, ErrorMessage = "Last Name must be within 0-30 characters")]
        public string LastName { get; set; }

        [Display(Name = "Enter Designation")]
        [Required(ErrorMessage = "Designation is Required")]
        [StringLength(30, MinimumLength = 1, ErrorMessage = "Designation must be within 0-30 characters")]
        public string Designation { get; set; }

        [Display(Name = "Enter Gender")]
        [Required(ErrorMessage = "Gender is Required")]
        [StringLength(30, MinimumLength = 1, ErrorMessage = "Gender must be within 0-30 characters")]
        public string Gender { get; set; }

        [Display(Name = "Enter Date of Joining")]
        [DataType(DataType.Date)]
        [Required(ErrorMessage = "Date of Joining is Required")]
        public DateTime DOJ { get; set; }

        [Display(Name = "Enter Phone Number")]
        [Required(ErrorMessage = "Phone Number is Required")]
        public long PhoneNumber { get; set; }

        [Display(Name = "Enter Mail ID")]
        [Required(ErrorMessage = "Mail ID is Required")]
        [StringLength(30, MinimumLength = 1, ErrorMessage = "MailID must be within 0-30 characters")]
        public string MailID { get; set; }

        [Display(Name = "Enter PAN")]
        [Required(ErrorMessage = "Date of Joining is Required")]
        [StringLength(30, MinimumLength = 1, ErrorMessage = "First Name must be within 0-30 characters")]
        public string PAN { get; set; }











    }
}
