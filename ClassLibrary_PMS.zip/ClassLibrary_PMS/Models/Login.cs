﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary_PMS.Models
{
    public class Login
    {
        [Key]
        [Required(ErrorMessage = "Serial Number is Required")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Serial_No { get; set; }


        [Display(Name = "Enter Password")]
        [Required(ErrorMessage = "Password is Required")]
        [StringLength(30, MinimumLength = 1, ErrorMessage = "Password must be within 1-30 characters")]
        public string Password { get; set; }


        [ForeignKey("Employee")]
        public string EmployeeID { get; set; }
        public virtual Employee Employee { get; set; }
    }
}
