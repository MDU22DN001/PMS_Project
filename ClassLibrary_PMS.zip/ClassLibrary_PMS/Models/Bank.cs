﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary_PMS.Models
{
    public class Bank
    {
        [Key]
        [Display(Name = "Enter Serial Number")]
        [Required(ErrorMessage = "Serial Number is Required")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Serial_No { get; set; }


        [Display(Name = "Enter Account Number")]
        [Required(ErrorMessage = "Account Number is Required")]
        public long Account_Number { get; set; }


        [Display(Name = "Enter IFSC")]
        [Required(ErrorMessage = "IFSC is Required")]
        [StringLength(25, MinimumLength = 10, ErrorMessage = "IFSC must be within 10-25 characters")]
        public string IFSC { get; set; }


        [Display(Name = "Enter Bank Name")]
        [Required(ErrorMessage = "Bank Name is Required")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Bank Name must be within 1-100 characters")]
        public string Bank_Name { get; set; }


        [ForeignKey("Employee")]
        public string EmployeeID { get; set; }
        public virtual Employee Employee  { get; set; }
    }
}
