﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary_PMS.Models
{
    public class Attendance
    {
        [Key]
        [Display(Name = "Enter the Attendance ID")]
        [Required(ErrorMessage = "Attendance ID is Required")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int AttendanceID { get; set; }


        [Display(Name = "Enter a Year")]
        [Required(ErrorMessage = "Year is Required")]
        public int Year { get; set; }

        [Display(Name = "Enter a Month")]
        [Required(ErrorMessage = "Month is Required")]
        public int Month { get; set; }

        [Display(Name = "Enter Total number of Days")]
        [Required(ErrorMessage = "Total_Days is Required")]
        public int Total_Days { get; set; }

        [Display(Name = "Enter ")]
        [Required(ErrorMessage = "Working_Days is Required")]
        public int Working_Days { get; set; }



        [ForeignKey("Employee")]
        public string EmployeeID { get; set; }
        public virtual Employee Employee { get; set; }
    }
}
