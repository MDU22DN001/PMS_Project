﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary_PMS.Models
{
    public class Salary_Splitup
    {
        [Key]
        [Display(Name = "Enter the Designation")]
        [Required(ErrorMessage = "Designation is Required")]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [StringLength(30, MinimumLength = 1, ErrorMessage = "Designation must be within 0-30 characters")]
        public string Designation { get; set; }



        [Display(Name = "Enter the Basic Pay")]
        [Required(ErrorMessage = "Basic Pay is Required")]
        public int Basic_Pay { get; set; }



        [Display(Name = "Enter the HRA")]
        [Required(ErrorMessage = "HRA is Required")]
        public int HRA { get; set; }




        [Display(Name = "Enter the PF")]
        [Required(ErrorMessage = "PF is Required")]
        public int PF { get; set; }




        [Display(Name = "Enter the Medical Allowance")]
        [Required(ErrorMessage = "Medical Allowance is Required")]
        public int Medical_Allowance { get; set; }




        [Display(Name = "Enter the Special Allowance")]
        [Required(ErrorMessage = "Special Allowance is Required")]
        public int Special_Allowance { get; set; }




        [Display(Name = "Enter the Tax Deduction")]
        [Required(ErrorMessage = "Tax Deduction is Required")]
        public int Tax_Deduction { get; set; }




        [Display(Name = "Enter the Gross Pay")]
        [Required(ErrorMessage = "Gross Pay is Required")]
        public int Gross_Pay { get; set; }




        [Display(Name = "Enter the Net Pay")]
        [Required(ErrorMessage = "Net Pay is Required")]
        public int Net_Pay { get; set; }
    }
}
