﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary_PMS.Models
{
    public class Payroll
    {
        [Key]
        [Display(Name = "Enter Serial No")]
        [Required(ErrorMessage = "Serial No is Required")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Serial_No { get; set; }


        [ForeignKey("Employee")]
        public string EmployeeID { get; set; }
        public virtual Employee Employee { get; set; }


        [ForeignKey("Salary_Splitup")]
        public string Designation { get; set; }
        public virtual Salary_Splitup Salary_Splitup { get; set; }


        [ForeignKey("Attendance")]
        public int AttendanceID { get; set; }
        public virtual Attendance Attendance { get; set; }
    }
}
